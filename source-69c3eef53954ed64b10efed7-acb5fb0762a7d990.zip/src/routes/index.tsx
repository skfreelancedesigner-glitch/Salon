import { createFileRoute } from '@tanstack/react-router'
import { useEffect, useRef, useState } from 'react'

export const Route = createFileRoute('/')({
  component: SalonHome,
})

/* ─── Scroll Animation Hook ─────────────────────────────────────────── */
function useScrollAnim() {
  useEffect(() => {
    const els = document.querySelectorAll('.anim')
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            const el = e.target as HTMLElement
            const delay = el.dataset.delay ?? '0'
            setTimeout(() => el.classList.add('visible'), Number(delay))
            obs.unobserve(el)
          }
        })
      },
      { threshold: 0.12 },
    )
    els.forEach((el) => obs.observe(el))
    return () => obs.disconnect()
  }, [])
}

/* ─── Navbar ─────────────────────────────────────────────────────────── */
function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const links = ['Home', 'About', 'Services', 'Gallery', 'Testimonials', 'Contact']

  return (
    <nav className={`navbar ${scrolled ? 'scrolled' : ''}`}>
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        {/* Logo */}
        <a href="#home" style={{ textDecoration: 'none' }}>
          <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.1 }}>
            <span className="font-display" style={{ color: '#fff', fontSize: '1.1rem', fontWeight: 700, letterSpacing: '0.02em' }}>
              Affinity Express
            </span>
            <span style={{ color: 'var(--gold)', fontSize: '0.65rem', letterSpacing: '0.25em', textTransform: 'uppercase', fontWeight: 500 }}>
              Hair & Beauty Studio
            </span>
          </div>
        </a>

        {/* Desktop links */}
        <div className="hidden md:flex" style={{ gap: '2rem', alignItems: 'center' }}>
          {links.map((l) => (
            <a
              key={l}
              href={`#${l.toLowerCase()}`}
              style={{
                color: 'rgba(245,240,232,0.75)',
                textDecoration: 'none',
                fontSize: '0.82rem',
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
                fontWeight: 500,
                transition: 'color 0.2s',
              }}
              onMouseEnter={(e) => ((e.target as HTMLElement).style.color = 'var(--gold)')}
              onMouseLeave={(e) => ((e.target as HTMLElement).style.color = 'rgba(245,240,232,0.75)')}
            >
              {l}
            </a>
          ))}
          <a href="#contact" className="btn-primary" style={{ padding: '0.55rem 1.25rem', fontSize: '0.72rem' }}>
            Book Now
          </a>
        </div>

        {/* Mobile hamburger */}
        <button
          className="md:hidden"
          onClick={() => setMenuOpen(!menuOpen)}
          style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '0.5rem' }}
          aria-label="Toggle menu"
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
            {[0, 1, 2].map((i) => (
              <span
                key={i}
                style={{
                  display: 'block',
                  width: '24px',
                  height: '2px',
                  background: 'var(--gold)',
                  transition: 'all 0.3s',
                  transform: menuOpen && i === 0 ? 'rotate(45deg) translate(5px,5px)' : menuOpen && i === 2 ? 'rotate(-45deg) translate(5px,-5px)' : 'none',
                  opacity: menuOpen && i === 1 ? 0 : 1,
                }}
              />
            ))}
          </div>
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div
          style={{
            background: 'rgba(10,10,10,0.98)',
            borderTop: '1px solid rgba(201,168,76,0.15)',
            padding: '1.5rem',
            display: 'flex',
            flexDirection: 'column',
            gap: '1.25rem',
          }}
        >
          {links.map((l) => (
            <a
              key={l}
              href={`#${l.toLowerCase()}`}
              onClick={() => setMenuOpen(false)}
              style={{
                color: 'rgba(245,240,232,0.8)',
                textDecoration: 'none',
                fontSize: '0.9rem',
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
                fontWeight: 500,
              }}
            >
              {l}
            </a>
          ))}
        </div>
      )}
    </nav>
  )
}

/* ─── Hero ───────────────────────────────────────────────────────────── */
function Hero() {
  return (
    <section
      id="home"
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'relative',
        overflow: 'hidden',
        background: `linear-gradient(135deg, #0a0a0a 0%, #1a0f0a 50%, #0a0a0a 100%)`,
      }}
    >
      {/* Decorative background pattern */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          backgroundImage: `radial-gradient(ellipse 80% 50% at 50% 60%, rgba(107,76,59,0.18) 0%, transparent 70%)`,
        }}
      />
      {/* Background image overlay */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          backgroundImage: `url(https://images.unsplash.com/photo-1560066984-138dadb4c035?w=1600&q=80)`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          opacity: 0.12,
        }}
      />

      {/* Gold corner accent */}
      <div style={{ position: 'absolute', top: 0, left: 0, width: '200px', height: '200px', background: 'linear-gradient(135deg, rgba(201,168,76,0.08), transparent)', pointerEvents: 'none' }} />
      <div style={{ position: 'absolute', bottom: 0, right: 0, width: '300px', height: '300px', background: 'linear-gradient(315deg, rgba(107,76,59,0.12), transparent)', pointerEvents: 'none' }} />

      <div style={{ position: 'relative', zIndex: 1, textAlign: 'center', padding: '2rem 1.5rem', maxWidth: '800px' }}>
        <div
          className="anim fade-up"
          style={{ display: 'inline-flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1.5rem' }}
        >
          <div style={{ height: '1px', width: '40px', background: 'var(--gold)' }} />
          <span style={{ color: 'var(--gold)', fontSize: '0.75rem', letterSpacing: '0.35em', textTransform: 'uppercase', fontWeight: 500 }}>
            Hyderabad's Premier Studio
          </span>
          <div style={{ height: '1px', width: '40px', background: 'var(--gold)' }} />
        </div>

        <h1
          className="font-display anim fade-up"
          data-delay="150"
          style={{ fontSize: 'clamp(2.5rem, 8vw, 5.5rem)', fontWeight: 700, lineHeight: 1.1, color: '#fff', marginBottom: '1.5rem' }}
        >
          Redefine Your
          <span style={{ display: 'block', color: 'var(--gold)', fontStyle: 'italic' }}>Style</span>
        </h1>

        <p
          className="anim fade-up"
          data-delay="300"
          style={{ fontSize: 'clamp(1rem, 2.5vw, 1.2rem)', color: 'rgba(245,240,232,0.7)', fontWeight: 300, lineHeight: 1.8, marginBottom: '2.5rem', maxWidth: '520px', margin: '0 auto 2.5rem' }}
        >
          Experience premium hair and beauty services in Hyderabad — where luxury meets artistry.
        </p>

        <div className="anim fade-up" data-delay="450" style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
          <a href="#contact" className="btn-primary">Book Appointment</a>
          <a href="#services" className="btn-outline">Our Services</a>
        </div>

        {/* Stats */}
        <div
          className="anim fade-up"
          data-delay="600"
          style={{
            display: 'flex',
            gap: '2.5rem',
            justifyContent: 'center',
            marginTop: '4rem',
            flexWrap: 'wrap',
          }}
        >
          {[['500+', 'Happy Clients'], ['10+', 'Expert Stylists'], ['4.8★', 'Average Rating']].map(([num, label]) => (
            <div key={label} style={{ textAlign: 'center' }}>
              <div className="font-display" style={{ fontSize: '1.75rem', fontWeight: 700, color: 'var(--gold)' }}>{num}</div>
              <div style={{ fontSize: '0.75rem', color: 'rgba(245,240,232,0.5)', letterSpacing: '0.12em', textTransform: 'uppercase', marginTop: '0.25rem' }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div
        style={{
          position: 'absolute',
          bottom: '2rem',
          left: '50%',
          transform: 'translateX(-50%)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '0.5rem',
          opacity: 0.5,
          animation: 'bounce 2s infinite',
        }}
      >
        <span style={{ fontSize: '0.65rem', letterSpacing: '0.2em', textTransform: 'uppercase', color: 'var(--gold)' }}>Scroll</span>
        <div style={{ width: '1px', height: '40px', background: 'linear-gradient(to bottom, var(--gold), transparent)' }} />
      </div>
      <style>{`@keyframes bounce { 0%,100%{transform:translateX(-50%) translateY(0)} 50%{transform:translateX(-50%) translateY(8px)} }`}</style>
    </section>
  )
}

/* ─── About ──────────────────────────────────────────────────────────── */
function About() {
  const features = [
    { icon: '✦', title: 'Expert Stylists', desc: 'Our certified professionals bring years of artistry and passion to every appointment.' },
    { icon: '◈', title: 'Premium Products', desc: 'We use only luxury, salon-grade products to protect and enhance your natural beauty.' },
    { icon: '❋', title: 'Personalized Care', desc: 'Every client receives a bespoke consultation tailored to their unique style vision.' },
  ]

  return (
    <section id="about" className="section" style={{ background: 'var(--black-soft)', position: 'relative' }}>
      <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px,1fr))', gap: '4rem', alignItems: 'center' }}>
          {/* Image */}
          <div className="anim fade-left" style={{ position: 'relative' }}>
            <img
              src="https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=800&q=80"
              alt="Salon interior"
              style={{ width: '100%', height: '480px', objectFit: 'cover', borderRadius: '4px', display: 'block' }}
            />
            <div
              style={{
                position: 'absolute',
                bottom: '-1.5rem',
                right: '-1.5rem',
                background: 'var(--deep-red)',
                padding: '1.5rem 2rem',
                borderRadius: '4px',
              }}
            >
              <div className="font-display" style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--gold)', lineHeight: 1 }}>8+</div>
              <div style={{ fontSize: '0.75rem', color: 'rgba(245,240,232,0.8)', letterSpacing: '0.1em', textTransform: 'uppercase', marginTop: '0.25rem' }}>Years of Excellence</div>
            </div>
          </div>

          {/* Content */}
          <div>
            <div className="anim fade-right" style={{ marginBottom: '0.75rem' }}>
              <span style={{ color: 'var(--gold)', fontSize: '0.75rem', letterSpacing: '0.3em', textTransform: 'uppercase', fontWeight: 500 }}>About Us</span>
            </div>
            <h2 className="font-display anim fade-right" data-delay="100" style={{ fontSize: 'clamp(1.8rem, 4vw, 2.75rem)', fontWeight: 700, color: '#fff', lineHeight: 1.2, marginBottom: '1.25rem' }}>
              Where Beauty Meets<br />
              <span style={{ color: 'var(--gold)', fontStyle: 'italic' }}>Artistry</span>
            </h2>
            <div className="gold-divider anim fade-right" data-delay="150" style={{ marginBottom: '1.5rem' }} />
            <p className="anim fade-right" data-delay="200" style={{ color: 'rgba(245,240,232,0.7)', lineHeight: 1.9, marginBottom: '2rem', fontWeight: 300 }}>
              Affinity Express Hair and Beauty Studio is Hyderabad's destination for luxury grooming and styling. Nestled in the heart of the city, we blend contemporary techniques with timeless elegance to deliver transformative experiences.
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              {features.map((f, i) => (
                <div
                  key={f.title}
                  className="anim fade-right"
                  data-delay={String(300 + i * 100)}
                  style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start' }}
                >
                  <span style={{ color: 'var(--gold)', fontSize: '1rem', marginTop: '0.1rem', flexShrink: 0, width: '20px' }}>{f.icon}</span>
                  <div>
                    <div style={{ fontWeight: 600, color: '#fff', marginBottom: '0.2rem', fontSize: '0.95rem' }}>{f.title}</div>
                    <div style={{ color: 'rgba(245,240,232,0.6)', fontSize: '0.875rem', lineHeight: 1.7, fontWeight: 300 }}>{f.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ─── Services ───────────────────────────────────────────────────────── */
function Services() {
  const services = [
    { image: 'https://images.unsplash.com/photo-1585747860019-8024b3913dcc?w=200&q=80', name: 'Haircut & Styling', price: '₹299', desc: 'Precision cuts crafted for your face shape and lifestyle.', tag: 'Most Popular' },
    { image: 'https://images.unsplash.com/photo-1621605815971-fbc98d665033?w=200&q=80', name: 'Beard Styling', price: '₹199', desc: 'Expert beard grooming, shaping, and conditioning treatments.' },
    { image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?w=200&q=80', name: 'Hair Spa', price: '₹999', desc: 'Deep nourishing treatments to restore shine, strength, and softness.' },
    { image: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=200&q=80', name: 'Facial Treatment', price: '₹799', desc: 'Rejuvenating facials tailored to your skin type and goals.' },
    { image: 'https://images.unsplash.com/photo-1562322140-8baeececf3df?w=200&q=80', name: 'Hair Coloring', price: '₹1499', desc: 'Vibrant, long-lasting color using professional-grade products.' },
  ]

  return (
    <section id="services" className="section" style={{ background: 'var(--black)' }}>
      <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
        <div className="anim fade-up" style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
          <span style={{ color: 'var(--gold)', fontSize: '0.75rem', letterSpacing: '0.3em', textTransform: 'uppercase', fontWeight: 500 }}>What We Offer</span>
          <h2 className="font-display" style={{ fontSize: 'clamp(1.8rem, 4vw, 2.75rem)', fontWeight: 700, color: '#fff', marginTop: '0.75rem', marginBottom: '1rem' }}>
            Our <span style={{ color: 'var(--gold)', fontStyle: 'italic' }}>Services</span>
          </h2>
          <div className="gold-divider" style={{ margin: '0 auto' }} />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1.5rem' }}>
          {services.map((s, i) => (
            <div
              key={s.name}
              className="service-card anim fade-up"
              data-delay={String(i * 80)}
            >
              {s.tag && (
                <span style={{
                  position: 'absolute',
                  top: '1rem',
                  right: '1rem',
                  background: 'var(--deep-red)',
                  color: 'var(--cream)',
                  fontSize: '0.6rem',
                  letterSpacing: '0.12em',
                  textTransform: 'uppercase',
                  padding: '0.25rem 0.6rem',
                  borderRadius: '2px',
                  fontWeight: 600,
                }}>
                  {s.tag}
                </span>
              )}
              <div style={{ width: '56px', height: '56px', borderRadius: '50%', overflow: 'hidden', marginBottom: '1rem', border: '2px solid rgba(201,168,76,0.3)' }}>
                <img src={s.image} alt={s.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} loading="lazy" />
              </div>
              <h3 style={{ color: '#fff', fontWeight: 600, fontSize: '1.05rem', marginBottom: '0.5rem' }}>{s.name}</h3>
              <p style={{ color: 'rgba(245,240,232,0.55)', fontSize: '0.85rem', lineHeight: 1.7, fontWeight: 300, marginBottom: '1.25rem' }}>{s.desc}</p>
              <div className="font-display" style={{ color: 'var(--gold)', fontSize: '1.5rem', fontWeight: 700 }}>{s.price}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ─── Gallery ────────────────────────────────────────────────────────── */
function Gallery() {
  const images = [
    { src: 'https://images.unsplash.com/photo-1595476108010-b4d1f102b1b1?w=600&q=80', label: 'Hair Styling' },
    { src: 'https://images.unsplash.com/photo-1562322140-8baeececf3df?w=600&q=80', label: 'Color Treatment' },
    { src: 'https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?w=600&q=80', label: 'Facial Glow' },
    { src: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=600&q=80', label: 'Spa Treatment' },
    { src: 'https://images.unsplash.com/photo-1599351431202-1e0f0137899a?w=600&q=80', label: 'Beard Art' },
    { src: 'https://images.unsplash.com/photo-1521590832167-7bcbfaa6381f?w=600&q=80', label: 'Salon Interior' },
  ]

  return (
    <section id="gallery" className="section" style={{ background: 'var(--black-soft)' }}>
      <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
        <div className="anim fade-up" style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
          <span style={{ color: 'var(--gold)', fontSize: '0.75rem', letterSpacing: '0.3em', textTransform: 'uppercase', fontWeight: 500 }}>Our Work</span>
          <h2 className="font-display" style={{ fontSize: 'clamp(1.8rem, 4vw, 2.75rem)', fontWeight: 700, color: '#fff', marginTop: '0.75rem', marginBottom: '1rem' }}>
            <span style={{ color: 'var(--gold)', fontStyle: 'italic' }}>Gallery</span>
          </h2>
          <div className="gold-divider" style={{ margin: '0 auto' }} />
        </div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
            gap: '1rem',
            gridAutoRows: '240px',
          }}
        >
          {images.map((img, i) => (
            <div
              key={img.src}
              className="gallery-item anim zoom-in"
              data-delay={String(i * 80)}
              style={{ gridRow: i === 0 || i === 3 ? 'span 2' : 'span 1' }}
            >
              <img src={img.src} alt={img.label} loading="lazy" />
              <div className="gallery-overlay" />
              <span
                style={{
                  position: 'absolute',
                  bottom: '1rem',
                  left: '1rem',
                  color: '#fff',
                  fontSize: '0.8rem',
                  fontWeight: 600,
                  letterSpacing: '0.1em',
                  textTransform: 'uppercase',
                  opacity: 0,
                  transition: 'opacity 0.35s ease',
                }}
                className="gallery-label"
              >
                {img.label}
              </span>
            </div>
          ))}
        </div>
      </div>
      <style>{`.gallery-item:hover .gallery-label { opacity: 1; }`}</style>
    </section>
  )
}

/* ─── Testimonials ───────────────────────────────────────────────────── */
function Testimonials() {
  const reviews = [
    { name: 'Priya Sharma', role: 'Regular Client', text: 'Absolutely stunning results! The team at Affinity Express transformed my look completely. The hair spa treatment left my hair feeling silky smooth for weeks.', stars: 5 },
    { name: 'Rahul Mehta', role: 'Verified Customer', text: "Best beard styling experience in Hyderabad. The attention to detail is remarkable. I won't trust anyone else with my grooming now.", stars: 5 },
    { name: 'Anjali Reddy', role: 'Loyal Customer', text: 'The facial treatment was absolutely divine! The products they use are top-notch and the ambience is so luxurious. Highly recommended!', stars: 5 },
    { name: 'Vikram Nair', role: 'New Customer', text: 'Came in for a haircut and was blown away by the professionalism. The stylist listened carefully to what I wanted and delivered perfection.', stars: 5 },
    { name: 'Sneha Patel', role: 'Regular Client', text: 'My hair coloring turned out exactly as I envisioned. The team is incredibly talented and the results are always salon-worthy. Love this place!', stars: 5 },
  ]

  const [active, setActive] = useState(0)

  useEffect(() => {
    const id = setInterval(() => setActive((a) => (a + 1) % reviews.length), 4500)
    return () => clearInterval(id)
  }, [reviews.length])

  return (
    <section id="testimonials" className="section" style={{ background: 'var(--black)' }}>
      <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
        <div className="anim fade-up" style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
          <span style={{ color: 'var(--gold)', fontSize: '0.75rem', letterSpacing: '0.3em', textTransform: 'uppercase', fontWeight: 500 }}>Client Stories</span>
          <h2 className="font-display" style={{ fontSize: 'clamp(1.8rem, 4vw, 2.75rem)', fontWeight: 700, color: '#fff', marginTop: '0.75rem', marginBottom: '0.75rem' }}>
            What Our Clients <span style={{ color: 'var(--gold)', fontStyle: 'italic' }}>Say</span>
          </h2>
          <div className="gold-divider" style={{ margin: '0 auto 1.25rem' }} />
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.5rem',
              background: 'rgba(201,168,76,0.1)',
              border: '1px solid rgba(201,168,76,0.25)',
              borderRadius: '100px',
              padding: '0.4rem 1rem',
            }}
          >
            <span style={{ color: 'var(--gold)', fontWeight: 700, fontSize: '0.9rem' }}>4.8</span>
            <span style={{ fontSize: '0.85rem' }}>⭐</span>
            <span style={{ color: 'rgba(245,240,232,0.6)', fontSize: '0.78rem' }}>rated on Google</span>
          </div>
        </div>

        {/* Featured review */}
        <div className="anim fade-up" data-delay="100" style={{ maxWidth: '700px', margin: '0 auto 2.5rem' }}>
          <div
            style={{
              background: 'var(--black-card)',
              border: '1px solid rgba(201,168,76,0.2)',
              borderRadius: '4px',
              padding: '2.5rem',
              textAlign: 'center',
              minHeight: '200px',
              transition: 'all 0.4s ease',
            }}
          >
            <div style={{ color: 'var(--gold)', fontSize: '1.5rem', marginBottom: '1.25rem' }}>
              {'★'.repeat(reviews[active].stars)}
            </div>
            <p
              className="font-display"
              style={{ color: 'rgba(245,240,232,0.85)', fontSize: '1.05rem', lineHeight: 1.8, fontStyle: 'italic', marginBottom: '1.5rem' }}
            >
              "{reviews[active].text}"
            </p>
            <div>
              <div style={{ color: '#fff', fontWeight: 600, fontSize: '0.9rem' }}>{reviews[active].name}</div>
              <div style={{ color: 'rgba(245,240,232,0.45)', fontSize: '0.78rem', marginTop: '0.2rem', letterSpacing: '0.08em', textTransform: 'uppercase' }}>{reviews[active].role}</div>
            </div>
          </div>
        </div>

        {/* Dots */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: '0.5rem' }}>
          {reviews.map((_, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              style={{
                width: i === active ? '24px' : '8px',
                height: '8px',
                borderRadius: '100px',
                background: i === active ? 'var(--gold)' : 'rgba(201,168,76,0.25)',
                border: 'none',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                padding: 0,
              }}
            />
          ))}
        </div>

        {/* All cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1.25rem', marginTop: '3rem' }}>
          {reviews.map((r, i) => (
            <div
              key={r.name}
              className={`testimonial-card anim fade-up ${i === active ? '' : ''}`}
              data-delay={String(i * 80)}
              style={{ cursor: 'pointer', borderColor: i === active ? 'rgba(201,168,76,0.4)' : undefined }}
              onClick={() => setActive(i)}
            >
              <div style={{ color: 'var(--gold)', fontSize: '0.85rem', marginBottom: '0.75rem' }}>{'★'.repeat(r.stars)}</div>
              <p style={{ color: 'rgba(245,240,232,0.65)', fontSize: '0.82rem', lineHeight: 1.7, fontStyle: 'italic', marginBottom: '1rem', fontWeight: 300 }}>
                "{r.text.slice(0, 90)}..."
              </p>
              <div style={{ color: '#fff', fontWeight: 600, fontSize: '0.85rem' }}>{r.name}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ─── Contact ────────────────────────────────────────────────────────── */
function Contact() {
  const [form, setForm] = useState({ name: '', phone: '', message: '' })
  const [sent, setSent] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSent(true)
    setForm({ name: '', phone: '', message: '' })
  }

  return (
    <section id="contact" className="section" style={{ background: 'var(--black-soft)' }}>
      <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px,1fr))', gap: '4rem', alignItems: 'start' }}>
          {/* Info */}
          <div>
            <div className="anim fade-left">
              <span style={{ color: 'var(--gold)', fontSize: '0.75rem', letterSpacing: '0.3em', textTransform: 'uppercase', fontWeight: 500 }}>Get In Touch</span>
            </div>
            <h2 className="font-display anim fade-left" data-delay="100" style={{ fontSize: 'clamp(1.8rem, 4vw, 2.5rem)', fontWeight: 700, color: '#fff', marginTop: '0.75rem', marginBottom: '1rem' }}>
              Book Your <span style={{ color: 'var(--gold)', fontStyle: 'italic' }}>Appointment</span>
            </h2>
            <div className="gold-divider anim fade-left" data-delay="150" style={{ marginBottom: '1.5rem' }} />

            <div className="anim fade-left" data-delay="200" style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              {[
                { icon: '📍', label: 'Address', val: 'Affinity Express, Hyderabad, Telangana' },
                { icon: '📞', label: 'Phone', val: '+91 98765 43210' },
                { icon: '🕐', label: 'Hours', val: 'Mon–Sat: 9AM – 8PM' },
              ].map((item) => (
                <div key={item.label} style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                  <span style={{ fontSize: '1.1rem', marginTop: '0.1rem' }}>{item.icon}</span>
                  <div>
                    <div style={{ color: 'var(--gold)', fontSize: '0.72rem', letterSpacing: '0.15em', textTransform: 'uppercase', fontWeight: 600, marginBottom: '0.15rem' }}>{item.label}</div>
                    <div style={{ color: 'rgba(245,240,232,0.75)', fontSize: '0.9rem', fontWeight: 300 }}>{item.val}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Form */}
          <div className="anim fade-right" data-delay="100">
            {sent ? (
              <div
                style={{
                  background: 'rgba(107,76,59,0.15)',
                  border: '1px solid rgba(107,76,59,0.4)',
                  borderRadius: '4px',
                  padding: '3rem 2rem',
                  textAlign: 'center',
                }}
              >
                <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>✨</div>
                <h3 className="font-display" style={{ color: 'var(--gold)', fontSize: '1.4rem', fontWeight: 700, marginBottom: '0.75rem' }}>Appointment Requested!</h3>
                <p style={{ color: 'rgba(245,240,232,0.7)', lineHeight: 1.7, fontSize: '0.9rem', fontWeight: 300 }}>
                  Thank you! Our team will contact you shortly to confirm your appointment at Affinity Express.
                </p>
                <button
                  onClick={() => setSent(false)}
                  className="btn-outline"
                  style={{ marginTop: '1.5rem' }}
                >
                  Book Another
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <div>
                  <label style={{ display: 'block', color: 'var(--gold)', fontSize: '0.72rem', letterSpacing: '0.15em', textTransform: 'uppercase', fontWeight: 600, marginBottom: '0.5rem' }}>
                    Full Name *
                  </label>
                  <input
                    className="form-input"
                    type="text"
                    placeholder="Your name"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                  />
                </div>
                <div>
                  <label style={{ display: 'block', color: 'var(--gold)', fontSize: '0.72rem', letterSpacing: '0.15em', textTransform: 'uppercase', fontWeight: 600, marginBottom: '0.5rem' }}>
                    Phone Number *
                  </label>
                  <input
                    className="form-input"
                    type="tel"
                    placeholder="+91 00000 00000"
                    required
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  />
                </div>
                <div>
                  <label style={{ display: 'block', color: 'var(--gold)', fontSize: '0.72rem', letterSpacing: '0.15em', textTransform: 'uppercase', fontWeight: 600, marginBottom: '0.5rem' }}>
                    Message
                  </label>
                  <textarea
                    className="form-input"
                    rows={4}
                    placeholder="Tell us about the service you'd like..."
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                  />
                </div>
                <button type="submit" className="btn-primary" style={{ alignSelf: 'flex-start' }}>
                  Send Request
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ─── Footer ─────────────────────────────────────────────────────────── */
function Footer() {
  return (
    <footer style={{ background: '#050505', borderTop: '1px solid rgba(201,168,76,0.1)', padding: '3rem 1.5rem 2rem' }}>
      <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px,1fr))', gap: '2.5rem', marginBottom: '3rem' }}>
          {/* Brand */}
          <div>
            <div className="font-display" style={{ color: '#fff', fontSize: '1.2rem', fontWeight: 700, marginBottom: '0.25rem' }}>
              Affinity Express
            </div>
            <div style={{ color: 'var(--gold)', fontSize: '0.65rem', letterSpacing: '0.25em', textTransform: 'uppercase', marginBottom: '1rem' }}>
              Hair & Beauty Studio
            </div>
            <p style={{ color: 'rgba(245,240,232,0.45)', fontSize: '0.82rem', lineHeight: 1.7, fontWeight: 300 }}>
              Premium hair & beauty services in the heart of Hyderabad. Redefine your style with us.
            </p>
          </div>

          {/* Links */}
          <div>
            <div style={{ color: 'var(--gold)', fontSize: '0.72rem', letterSpacing: '0.2em', textTransform: 'uppercase', fontWeight: 600, marginBottom: '1rem' }}>Quick Links</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
              {['Home', 'About', 'Services', 'Gallery', 'Contact'].map((l) => (
                <a
                  key={l}
                  href={`#${l.toLowerCase()}`}
                  style={{ color: 'rgba(245,240,232,0.5)', textDecoration: 'none', fontSize: '0.85rem', fontWeight: 300, transition: 'color 0.2s' }}
                  onMouseEnter={(e) => ((e.target as HTMLElement).style.color = 'var(--gold)')}
                  onMouseLeave={(e) => ((e.target as HTMLElement).style.color = 'rgba(245,240,232,0.5)')}
                >
                  {l}
                </a>
              ))}
            </div>
          </div>

          {/* Social */}
          <div>
            <div style={{ color: 'var(--gold)', fontSize: '0.72rem', letterSpacing: '0.2em', textTransform: 'uppercase', fontWeight: 600, marginBottom: '1rem' }}>Follow Us</div>
            <div style={{ display: 'flex', gap: '1rem' }}>
              {[
                {
                  label: 'Instagram',
                  icon: (
                    <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                    </svg>
                  ),
                },
                {
                  label: 'Facebook',
                  icon: (
                    <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                    </svg>
                  ),
                },
              ].map((s) => (
                <a
                  key={s.label}
                  href="#"
                  aria-label={s.label}
                  style={{
                    width: '40px',
                    height: '40px',
                    borderRadius: '2px',
                    border: '1px solid rgba(201,168,76,0.2)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'rgba(245,240,232,0.5)',
                    transition: 'all 0.3s',
                    textDecoration: 'none',
                  }}
                  onMouseEnter={(e) => {
                    const el = e.currentTarget as HTMLElement
                    el.style.borderColor = 'var(--gold)'
                    el.style.color = 'var(--gold)'
                    el.style.background = 'rgba(201,168,76,0.08)'
                  }}
                  onMouseLeave={(e) => {
                    const el = e.currentTarget as HTMLElement
                    el.style.borderColor = 'rgba(201,168,76,0.2)'
                    el.style.color = 'rgba(245,240,232,0.5)'
                    el.style.background = 'transparent'
                  }}
                >
                  {s.icon}
                </a>
              ))}
            </div>
          </div>
        </div>

        <div
          style={{
            borderTop: '1px solid rgba(201,168,76,0.08)',
            paddingTop: '1.5rem',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: '0.75rem',
          }}
        >
          <span style={{ color: 'rgba(245,240,232,0.3)', fontSize: '0.78rem' }}>
            © {new Date().getFullYear()} Affinity Express Hair and Beauty Studio, Hyderabad. All rights reserved.
          </span>
          <span style={{ color: 'rgba(201,168,76,0.4)', fontSize: '0.72rem', letterSpacing: '0.1em' }}>
            Hyderabad, Telangana, India
          </span>
        </div>
      </div>
    </footer>
  )
}

/* ─── Main Page ──────────────────────────────────────────────────────── */
function SalonHome() {
  useScrollAnim()

  return (
    <div>
      <Navbar />
      <Hero />
      <About />
      <Services />
      <Gallery />
      <Testimonials />
      <Contact />
      <Footer />
    </div>
  )
}
