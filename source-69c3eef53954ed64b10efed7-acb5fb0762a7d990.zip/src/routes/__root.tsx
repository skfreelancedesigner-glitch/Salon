import { HeadContent, Outlet, Scripts, createRootRoute } from '@tanstack/react-router'

import '../styles.css'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { title: 'Best Hair & Beauty Salon in Hyderabad | Affinity Express' },
      {
        name: 'description',
        content:
          'Affinity Express Hair and Beauty Studio — premium hair & beauty services in Hyderabad. Expert stylists, luxury products, and personalized care. Book your appointment today.',
      },
      { name: 'keywords', content: 'hair salon Hyderabad, beauty studio Hyderabad, haircut, facial, hair spa, hair coloring, beard styling' },
      { property: 'og:title', content: 'Best Hair & Beauty Salon in Hyderabad | Affinity Express' },
      { property: 'og:description', content: 'Premium hair & beauty services in Hyderabad. Expert stylists, luxury products.' },
    ],
  }),
  shellComponent: RootDocument,
})

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=Inter:wght@300;400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  )
}
